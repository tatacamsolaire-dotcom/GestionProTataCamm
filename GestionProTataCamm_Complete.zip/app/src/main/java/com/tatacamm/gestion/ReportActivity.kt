package com.tatacamm.gestion

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class ReportActivity : AppCompatActivity() {
    lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)
        db = DBHelper(this)

        val txtReport = findViewById<TextView>(R.id.txtReport)
        txtReport.text = generateReport()
    }

    private fun generateReport(): String {
        val sb = StringBuilder()
        var totalProfit = 0L
        var yourShare = 0L
        var investorShare = 0L

        val s = db.getSales()
        while (s.moveToNext()) {
            val productId = s.getInt(2)
            val qty = s.getInt(3)
            val price = s.getInt(4)
            val installation = s.getInt(5) == 1
            val c = db.getProductById(productId)
            if (c.moveToFirst()) {
                val cost = c.getInt(3)
                val profitPerUnit = price - cost
                var profit = profitPerUnit * qty
                if (installation) profit += 10000 * qty
                totalProfit += profit
                val your = (profit * 60) / 100
                val inv = profit - your
                yourShare += your
                investorShare += inv
            }
            c.close()
        }
        s.close()

        sb.append("Bénéfice brut total: " + totalProfit + "\n")
        sb.append("Ta part (60%): " + yourShare + "\n")
        sb.append("Investisseur (40%): " + investorShare + "\n")
        return sb.toString()
    }
}
