package com.tatacamm.gestion

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    companion object {
        private const val DB_NAME = "tatacamm.db"
        private const val DB_VERSION = 1

        const val T_STOCK = "stock"
        const val T_SALES = "sales"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createStock = "CREATE TABLE $T_STOCK (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, qty INTEGER, cost INTEGER, price INTEGER)"
        val createSales = "CREATE TABLE $T_SALES (id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT, product_id INTEGER, qty INTEGER, price INTEGER, installation INTEGER, date TEXT)"
        db.execSQL(createStock)
        db.execSQL(createSales)

        val cv = ContentValues()
        cv.put("name", "V380 Pro")
        cv.put("qty", 20)
        cv.put("cost", 30000)
        cv.put("price", 50000)
        db.insert(T_STOCK, null, cv)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $T_STOCK")
        db.execSQL("DROP TABLE IF EXISTS $T_SALES")
        onCreate(db)
    }

    fun addStock(name: String, qty: Int, cost: Int, price: Int) {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("name", name)
        cv.put("qty", qty)
        cv.put("cost", cost)
        cv.put("price", price)
        db.insert(T_STOCK, null, cv)
    }

    fun updateStockQty(productId: Int, delta: Int) {
        val db = writableDatabase
        db.execSQL("UPDATE $T_STOCK SET qty = qty + ? WHERE id = ?", arrayOf(delta.toString(), productId.toString()))
    }

    fun getStock(): Cursor {
        val db = readableDatabase
        return db.rawQuery("SELECT id, name, qty, cost, price FROM $T_STOCK", null)
    }

    fun getProductById(productId: Int): Cursor {
        val db = readableDatabase
        return db.rawQuery("SELECT id, name, qty, cost, price FROM $T_STOCK WHERE id = ?", arrayOf(productId.toString()))
    }

    fun addSale(client: String, productId: Int, qty: Int, price: Int, installation: Boolean, date: String) {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("client", client)
        cv.put("product_id", productId)
        cv.put("qty", qty)
        cv.put("price", price)
        cv.put("installation", if (installation) 1 else 0)
        cv.put("date", date)
        db.insert(T_SALES, null, cv)
        updateStockQty(productId, -qty)
    }

    fun getSales(): Cursor {
        val db = readableDatabase
        return db.rawQuery("SELECT id, client, product_id, qty, price, installation, date FROM $T_SALES ORDER BY date DESC", null)
    }
}
