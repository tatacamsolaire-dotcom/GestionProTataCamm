package com.tatacamm.gestion

import android.app.DatePickerDialog
import android.database.Cursor
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class SalesActivity : AppCompatActivity() {
    lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sales)
        db = DBHelper(this)

        val edtClient = findViewById<EditText>(R.id.edtClient)
        val edtProductId = findViewById<EditText>(R.id.edtProductId)
        val edtQty = findViewById<EditText>(R.id.edtQtySale)
        val chkInstall = findViewById<CheckBox>(R.id.chkInstall)
        val btnAddSale = findViewById<Button>(R.id.btnAddSale)
        val txtSales = findViewById<TextView>(R.id.txtSalesList)
        val btnRefreshSales = findViewById<Button>(R.id.btnRefreshSales)
        val btnPickDate = findViewById<Button>(R.id.btnPickDate)
        val txtDate = findViewById<TextView>(R.id.txtDate)

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        txtDate.text = sdf.format(Date())
        btnPickDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                val c = Calendar.getInstance()
                c.set(y, m, d)
                txtDate.text = sdf.format(c.time)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        btnAddSale.setOnClickListener {
            val client = edtClient.text.toString().ifEmpty { "Client" }
            val productId = edtProductId.text.toString().toIntOrNull() ?: 1
            val qty = edtQty.text.toString().toIntOrNull() ?: 1
            val installation = chkInstall.isChecked
            val date = txtDate.text.toString()

            val c: Cursor = db.getProductById(productId)
            if (c.moveToFirst()) {
                val price = c.getInt(4)
                db.addSale(client, productId, qty, price, installation, date)
                Toast.makeText(this, "Vente enregistrée", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Produit introuvable (vérifier ID)", Toast.LENGTH_SHORT).show()
            }
            c.close()
            edtClient.setText("")
            edtQty.setText("")
            refreshSales(txtSales)
        }

        btnRefreshSales.setOnClickListener { refreshSales(txtSales) }

        refreshSales(txtSales)
    }

    private fun refreshSales(txt: TextView) {
        val c = db.getSales()
        val sb = StringBuilder()
        while (c.moveToNext()) {
            val id = c.getInt(0)
            val client = c.getString(1)
            val pid = c.getInt(2)
            val qty = c.getInt(3)
            val price = c.getInt(4)
            val install = c.getInt(5) == 1
            val date = c.getString(6)
            sb.append("ID:$id  $date  $client  PID:$pid  QTY:$qty  PRICE:$price  INSTALL:${if (install) "Yes" else "No"}\n")
        }
        txt.text = sb.toString()
        c.close()
    }
}
