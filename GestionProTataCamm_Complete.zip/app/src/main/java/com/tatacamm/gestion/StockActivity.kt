package com.tatacamm.gestion

import android.database.Cursor
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.lang.StringBuilder

class StockActivity : AppCompatActivity() {
    lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock)
        db = DBHelper(this)

        val edtName = findViewById<EditText>(R.id.edtName)
        val edtQty = findViewById<EditText>(R.id.edtQty)
        val edtCost = findViewById<EditText>(R.id.edtCost)
        val edtPrice = findViewById<EditText>(R.id.edtPrice)
        val btnAdd = findViewById<Button>(R.id.btnAddStock)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshStock)
        val txtList = findViewById<TextView>(R.id.txtStockList)

        btnAdd.setOnClickListener {
            val name = edtName.text.toString().ifEmpty { "V380 Pro" }
            val qty = edtQty.text.toString().toIntOrNull() ?: 0
            val cost = edtCost.text.toString().toIntOrNull() ?: 30000
            val price = edtPrice.text.toString().toIntOrNull() ?: 50000
            db.addStock(name, qty, cost, price)
            edtName.setText("")
            edtQty.setText("")
            edtCost.setText("")
            edtPrice.setText("")
            refreshStock(txtList)
        }

        btnRefresh.setOnClickListener { refreshStock(txtList) }

        refreshStock(txtList)
    }

    private fun refreshStock(txt: TextView) {
        val c: Cursor = db.getStock()
        val sb = StringBuilder()
        while (c.moveToNext()) {
            val id = c.getInt(0)
            val name = c.getString(1)
            val qty = c.getInt(2)
            val cost = c.getInt(3)
            val price = c.getInt(4)
            sb.append("ID:$id  $name  QTY:$qty  COST:$cost  PRICE:$price\n")
        }
        txt.text = sb.toString()
        c.close()
    }
}
