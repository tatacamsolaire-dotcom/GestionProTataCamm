package com.tatacamm.gestion

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.txtSlogan).text = "La sécurité sans limites"
        findViewById<TextView>(R.id.txtPhone).text = "+223 7296 0628"

        val stockBtn: Button = findViewById(R.id.btnStock)
        val salesBtn: Button = findViewById(R.id.btnSales)
        val reportBtn: Button = findViewById(R.id.btnReport)

        stockBtn.setOnClickListener {
            startActivity(Intent(this, StockActivity::class.java))
        }

        salesBtn.setOnClickListener {
            startActivity(Intent(this, SalesActivity::class.java))
        }

        reportBtn.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
    }
}
