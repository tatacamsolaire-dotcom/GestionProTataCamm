Projet: Gestion Pro TATA CAMM (version COMPLETE)
Description: Application Android simple en français pour gérer le stock, ventes et rapports.

Instructions rapides:
1) Décompresse le dossier.
2) Crée un repo sur GitHub (nom: GestionProTataCamm) dans ton compte (tatacamsolaire-dotcom).
3) Pousse les fichiers du projet dans le repo (tu peux uploader le ZIP via l'interface GitHub -> Add file -> Upload files).
4) Dans GitHub, active la branche main et ouvre l'onglet Actions -> tu verras le workflow 'Build Android APK'. Lance-le (ou fais un push sur main).
5) Après exécution, va dans l'exécution du workflow -> Artifacts -> télécharge 'app-debug-apk' qui contient l APK.

Si tu veux, je peux te donner les commandes Git (windows/mac) pour pousser le repo depuis ton téléphone via Termux ou depuis un PC.

Remarques:
- Le projet est prêt à être compilé par GitHub Actions et produira un app-debug.apk.
- Si tu veux une version signée pour le Play Store, je t'expliquerai comment générer une clé et signer l'APK.
